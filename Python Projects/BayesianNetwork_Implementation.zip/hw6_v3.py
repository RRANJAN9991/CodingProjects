import pandas as pd
from sklearn.preprocessing import LabelEncoder
from pgmpy.models import BayesianModel
from pgmpy.inference import VariableElimination
from pgmpy.inference.EliminationOrder import MinFill
from sklearn.preprocessing import KBinsDiscretizer
import matplotlib.pyplot as plt
import networkx as nx

# Define the Bayesian Network structure
edges = [
    ('parental level of education', 'race/ethnicity'),
    ('math score', 'race/ethnicity'),
    ('reading score', 'race/ethnicity'),
    ('writing score', 'race/ethnicity'),
    ('lunch', 'race/ethnicity'),
    ('test preparation course', 'race/ethnicity')
]

# Create a directed graph
G = nx.DiGraph(edges)

# Draw the graph
pos = nx.spring_layout(G) 
nx.draw(G, pos, with_labels=True, node_size=3000, node_color="skyblue", font_size=10, font_color="black", font_weight="bold", arrowsize=20, edge_color="gray", linewidths=1, alpha=0.7)

# Display the graph
plt.title("Bayesian Network Structure")
plt.show()
# Load your data
data = pd.read_csv('combined_file_v4.csv')  # Replace with the actual filename

# Separate label encoders for each categorical feature
le_parental_education = LabelEncoder()
le_race_ethnicity = LabelEncoder()
le_lunch = LabelEncoder()
le_test_prep = LabelEncoder()

# Fit and transform each categorical feature
data['parental level of education'] = le_parental_education.fit_transform(data['parental level of education'])
data['race/ethnicity'] = le_race_ethnicity.fit_transform(data['race/ethnicity'])
data['lunch'] = le_lunch.fit_transform(data['lunch'])
data['test preparation course'] = le_test_prep.fit_transform(data['test preparation course'])

# Discretize the continuous features
discretizer = KBinsDiscretizer(n_bins=5, encode='ordinal', strategy='uniform')
scores = ['math score', 'reading score', 'writing score']
data[scores] = discretizer.fit_transform(data[scores])

# Print unique values of discretized features
for score in scores:
    print(f"Unique values in '{score}':", data[score].unique())

# Define the Bayesian Network structure
model = BayesianModel([
    ('parental level of education', 'race/ethnicity'),
    ('math score', 'race/ethnicity'),
    ('reading score', 'race/ethnicity'),
    ('writing score', 'race/ethnicity'),
    ('lunch', 'race/ethnicity'),
    ('test preparation course', 'race/ethnicity')
])

# Train the Bayesian Network
model.fit(data)

# Function to predict parental level of education
def predict_parental_education(math_score_input, reading_score_input, writing_score_input,
                               race_input, lunch_input, test_prep_input):
    # Check unique values in the categorical variables
    race = le_race_ethnicity.transform([race_input])[0]
    lunch = le_lunch.transform([lunch_input])[0]
    test_prep = le_test_prep.transform([test_prep_input])[0]
    
    # Discretize all user-provided scores at once
    user_scores = [[math_score_input, reading_score_input, writing_score_input]]
    discretized_scores = discretizer.transform(user_scores)[0]

    evidence = {
        'race/ethnicity': race,
        'lunch': lunch,
        'test preparation course': test_prep,
        'math score': discretized_scores[0],
        'reading score': discretized_scores[1],
        'writing score': discretized_scores[2]
    }

    # Use MinFill for elimination order without considering evidence variables
    elimination_order = MinFill(model).get_elimination_order(['parental level of education'])
    elimination_order = [var for var in elimination_order if var not in evidence and var != 'parental level of education']

    # Use BucketElimination for inference
    try:
        predictions = VariableElimination(model).map_query(
            variables=['parental level of education'],
            evidence=evidence,
            elimination_order=elimination_order
        )
        predicted_parental_education = le_parental_education.inverse_transform([predictions['parental level of education']])[0]

        print(f"Predicted Parental Level of Education: {predicted_parental_education}")

    except Exception as e:
        print("Error during inference:", e)
        print("Evidence:", evidence)
        print("Elimination Order:", elimination_order)
        print("Model variables:", model.nodes())
        raise  # Re-raise the exception for further analysis

# Example: Predict parental level of education based on user-provided scores and features
input_values = [
    (87, 92, 88, 'group A', 'standard', 'none'),  # High scores and diverse features
    (30, 40, 35, 'group C', 'free/reduced', 'completed'),  # Low scores and diverse features
    (75, 90, 80, 'group B', 'standard', 'none'),  # Medium scores and diverse features
]

for i, (math_score, reading_score, writing_score, race, lunch, test_prep) in enumerate(input_values, 1):
    print(f"\nIteration {i}:")
    predict_parental_education(math_score, reading_score, writing_score, race, lunch, test_prep)
