import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import os
import numpy as np

# Load the data into a DataFrame
df = pd.read_csv('Customers_Altered.csv')



# Define features and class variable
X = df[['Age', 'Spending Score (1-100)', 'Family Size']]
y = df['Annual Income ($)']

# Define income segments 
income_segments = pd.cut(y, bins=[-1, 55000, 110000, np.inf], labels=['Low', 'Medium', 'High'])

# Split the data into training and testing sets (80% training, 20% testing)
X_train, X_test, y_train, y_test = train_test_split(X, income_segments, test_size=0.2, random_state=42)


# Get user inputs for the four features
age = float(input("Enter Age: "))
spending_score = float(input("Enter Spending Score (1-100): "))
family_size = float(input("Enter Family Size: "))

# Prepare user input for prediction
user_input = [[age, spending_score, family_size]]

# Initialize the Decision Tree Classifier 
model = DecisionTreeClassifier(random_state=42, min_samples_split=4, max_depth=4)

# Train the model on the training data
model.fit(X_train, y_train)

# Predict income segments on the testing data
y_pred = model.predict(X_test)

# Predict the income segment probabilities for user input
user_segment_probabilities = model.predict_proba(user_input)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)



# Add predicted income segment to the DataFrame
X_test['Predicted Income Segment'] = y_pred

# Add column for whether predicted is true or false
X_test['Predicted Correct'] = (y_pred == y_test).astype(int)





# Print the predicted probabilities
print(f"Predicted Probabilities for Low, Medium, High Income Segments: {user_segment_probabilities[0]}")

print(f"Accuracy: {accuracy:.2f}")




# 1. Size per Segment (Customer Groups) Pie Chart
segment_counts = X_test['Predicted Income Segment'].value_counts()
plt.figure(figsize=(8, 6))
plt.pie(segment_counts, labels=segment_counts.index, autopct='%1.1f%%', startangle=140, colors=sns.color_palette('pastel'))
plt.title('Size per Segment (Customer Groups)')
plt.show()

# 2. Age Distribution by Segment 
plt.figure(figsize=(10, 6))
sns.histplot(data=X_test, x='Age', hue='Predicted Income Segment', multiple='stack', kde=True, palette='pastel')
plt.title('Age Distribution by Segment')
plt.show()

# 3. Spending Score Distribution by Segment 
plt.figure(figsize=(10, 6))
sns.histplot(data=X_test, x='Spending Score (1-100)', hue='Predicted Income Segment', multiple='stack', kde=True, palette='pastel')
plt.title('Spending Score Distribution by Segment')
plt.show()


# 5. Family Size by Segment
plt.figure(figsize=(10, 6))
sns.boxplot(data=X_test, x='Predicted Income Segment', y='Family Size', palette='pastel')
plt.title('Family Size by Segment')
plt.show()


