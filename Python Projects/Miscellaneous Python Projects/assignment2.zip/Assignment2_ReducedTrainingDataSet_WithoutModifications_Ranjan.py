import tensorflow as tf

# INTENT: Load the MNIST data and show it, raw, on the monitor

mnist = tf.keras.datasets.mnist # one of a handful of data sets known to Keras/TensorFlow
# mnist.load_data() produces a pair of input/output tensors for training
# and one for testing.



(x_train, y_train), (x_test, y_test) = mnist.load_data()

x_train = x_train[:5000]
y_train = y_train[:5000]



print("===========y_train===========")
print(tf.shape(y_train))
print(y_train)
x_train, x_test = x_train / 255.0, x_test / 255.0 # scale down input
print("===========x_train===========")
print(tf.shape(x_train))
print("===========x_train element 0 (28 rows of 28 gray values)===========")
print(x_train[0])

model = tf.keras.models.Sequential([ # layer format for the neural net
  tf.keras.layers.Flatten(input_shape=(28, 28)), # each pixel (grayscale value) mapped to one of 784 nodes
  tf.keras.layers.Dense(128, activation='relu'), # fully connected to hidden layer with relu
  # Dropout layer randomly sets its input units to 0 at 20% rate at each training step
  # The other inputs are scaled up by 1/0.8 so sum over all inputs is unchanged
  # Illustrative figure: http://laid.delanover.com/wp-content/uploads/2018/02/dropout.png
  # (see https://www.tensorflow.org/api_docs/python/tf/keras/layers/Dropout)
  tf.keras.layers.Dropout(0.2),
  tf.keras.layers.Dense(10) # e.g., output #7 expresses degree to which the input is a 7
])

print("===========first element of x_train (29 rows)===========")
print(x_train[:1])

predictions = model(x_train[:1]).numpy() # numpy() converts the tensor output
print("===========untrained output of first training set input===========")

tf.nn.softmax(predictions).numpy()

loss_fn = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)

loss_fn(y_train[:1], predictions).numpy()

# Put together the NN with training process, loss, and means of evaluation.
# 'accuracy' = proportion of correct predictions vs. total number of cases
model.compile(optimizer='adam',
              loss=loss_fn,
              metrics=['accuracy'])

model.fit(x_train, y_train, epochs=5)

model.evaluate(x_test,  y_test, verbose=2)

probability_model = tf.keras.Sequential([
  model,
  tf.keras.layers.Softmax()
])
