import tensorflow as tf
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import os
import numpy as np

# Load the data into a DataFrame

df = pd.read_csv('Customers.csv')

# Encoding gender using LabelEncoder
le = LabelEncoder()
df['Gender'] = le.fit_transform(df['Gender'])

# Drop unnecessary columns like 'CustomerID' and 'Profession'
df = df.drop(['CustomerID', 'Profession'], axis=1)

# Handling missing values and encoding other categorical variables if needed

# Grouping income into classes: Low, Medium, High
df['IncomeClass'] = pd.cut(df['Annual Income ($)'], bins=[-1, 55000, 110000, np.inf], labels=['Low', 'Medium', 'High'])

# Splitting data into features (X) and target variable (y)
X = df.drop(['Annual Income ($)', 'IncomeClass'], axis=1)
y = df['IncomeClass']

# Encoding the target variable
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(y)

# Splitting data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Neural network model
model = tf.keras.models.Sequential([
    tf.keras.layers.Dense(128, activation='relu', input_shape=(X_train.shape[1],)),
    tf.keras.layers.Dropout(0.2),
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(32, activation='relu'),  # Additional hidden layer
    tf.keras.layers.Dense(3, activation='softmax')  # Output layer with 3 neurons for Low, Medium, High
])

# Compile the model
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# Train the model
model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_test, y_test))

user_input = {}
for feature in X.columns:
    if feature == 'Gender':
        value = input(f"Enter {feature} (Male or Female): ")
    else:
        value = float(input(f"Enter {feature}: "))
    user_input[feature] = value

# Convert user input to DataFrame
user_df = pd.DataFrame([user_input])

# Encode categorical features
user_df['Gender'] = le.transform(user_df['Gender'])

# Get predictive probabilities
predictions = model.predict(user_df)

# Print predictive probabilities
print("Predictive Probabilities:")
for i, prob in enumerate(predictions[0]):
    print(f"Income Class {label_encoder.classes_[i]}: {prob}")

# Evaluate the model on test data
test_loss, test_accuracy = model.evaluate(X_test, y_test)
print(f"\nTest Accuracy: {test_accuracy}")





# Assuming 'df' is the original DataFrame with the data
sns.set(style="whitegrid")

# Assuming 'df' is the original DataFrame with the data
sns.set(style="whitegrid")

# Plotting gender distribution
plt.figure(figsize=(12, 6))
sns.countplot(x='IncomeClass', hue='Gender', data=df)
plt.title('Gender Distribution in Income Segments')
plt.xlabel('Income Class')
plt.ylabel('Count')
plt.show()

# Plotting spending score distribution
plt.figure(figsize=(12, 6))
sns.boxplot(x='IncomeClass', y='Spending Score (1-100)', data=df)
plt.title('Spending Score Distribution in Income Segments')
plt.xlabel('Income Class')
plt.ylabel('Spending Score')
plt.show()

# Plotting years of experience distribution
plt.figure(figsize=(12, 6))
sns.boxplot(x='IncomeClass', y='Work Experience', data=df)
plt.title('Years of Experience Distribution in Income Segments')
plt.xlabel('Income Class')
plt.ylabel('Years of Experience')
plt.show()




