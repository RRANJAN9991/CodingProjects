import random

# Define sample cities and distances
cities = ["Boston", "London", "Mumbai", "Shanghai"]
distances = {
    ("Boston", "London"): 3,
    ("London", "Boston"): 3,  # Bidirectional distance
    ("London", "Mumbai"): 4.5,
    ("Mumbai", "London"): 4.5,  # Bidirectional distance
    ("Mumbai", "Shanghai"): 3.1,
    ("Shanghai", "Mumbai"): 3.1,  # Bidirectional distance
    ("Shanghai", "London"): 5.7,
    ("London", "Shanghai"): 5.7,  # Bidirectional distance
    ("Boston", "Mumbai"): 7.6,
    ("Mumbai", "Boston"): 7.6,  # Bidirectional distance
    ("Boston", "Shanghai"): 7.8,
    ("Shanghai", "Boston"): 7.8,  # Bidirectional distance
}



# Genetic Algorithm parameters
population_size = 10
generations = 50
mutation_rate = 0.1
t = 3
# Print all possible (2 city) routes with distances for the original data
print("All Possible (2 city) Routes for Original Data:")
for i in range(len(cities)):
    for j in range(i + 1, len(cities)):
        distance = distances[(cities[i], cities[j])]
        print(f"{cities[i]} -> {cities[j]} ({distance})")
# Print representation of routes without distances for the original data
print("\nRepresentation of Routes for Original Data:")
for i in range(len(cities)):
    for j in range(i + 1, len(cities)):
        route = [cities[i], cities[j], cities[i]]  # Closing the loop
        print(" -> ".join(route))
# Function to initialize a random route
def initialize_route(cities):
    route = cities[:]
    random.shuffle(route)
    return route

# Function to calculate the total distance of a route
def calculate_distance(route, distances):
    total_distance = 0
    for i in range(len(route) - 1):
        total_distance += distances[(route[i], route[i + 1])]
    total_distance += distances[(route[-1], route[0])]  # Return to starting city
    return total_distance

def t_order_crossover(parent1, parent2, t):
    # Choose a random crossover point
    crossover_point = random.randint(0, len(parent1) - 1)

    # Copy the segment from parent1 to the child
    child = parent1[crossover_point : crossover_point + t]

    # Fill in the remaining positions from parent2, preserving the order
    index = (crossover_point + t) % len(parent2)
    while len(child) < len(parent1):
        city = parent2[index]
        if city not in child:
            child.append(city)
        index = (index + 1) % len(parent2)

    return child


def mutate(route):
    start, end = random.sample(range(len(route)), 2)
    route[start], route[end] = route[end], route[start]
    return route

# Main Genetic Algorithm
population = [initialize_route(cities) for _ in range(population_size)]

for generation in range(generations):
    # Evaluate fitness
    fitness_scores = [1 / calculate_distance(route, distances) for route in population]

    # Select parents for crossover
    parents = random.choices(population, weights=fitness_scores, k=2)

    # Perform order crossover
    child = t_order_crossover(parents[0], parents[1], t)

    # Print representation of data for the current child route
    print(f"\nGeneration {generation + 1} - Representation of Data for Child Route:")
    for i in range(len(child) - 1):
        city1, city2 = child[i], child[i + 1]
        distance = distances[(city1, city2)]
        print(f"{city1} -> {city2} ({distance})")
    # Add a line for returning to the original starting city
    return_distance = distances[(child[-1], child[0])]
    print(f"{child[-1]} -> {child[0]} ({return_distance})")

    # Perform mutation
    if random.random() < mutation_rate:
        child = mutate(child)

    # Replace the least fit individual in the population with the new child
    population[fitness_scores.index(min(fitness_scores))] = child

    # Print representation of child route after mutation
    print(f"\nGeneration {generation + 1} - Child Route Representation: {' -> '.join(child)}")
    # Add a line for returning to the original starting city in the child route
    child_return_distance = distances[(child[-1], child[0])]
    print(f" -> {child[0]}")


# Print initial route
initial_route = cities + [cities[0]]
print("Initial Route:")
for i in range(len(initial_route) - 1):
    print(f"{initial_route[i]} -> {initial_route[i + 1]} ({distances[(initial_route[i], initial_route[i + 1])]})")

# Print best route after 50 generations
best_route = min(population, key=lambda route: calculate_distance(route, distances))
best_route.append(best_route[0])  # Add the starting city to complete the cycle

print("\nBest Route after 50 Generations:")
for i in range(len(best_route) - 1):
    print(f"{best_route[i]} -> {best_route[i + 1]} ({distances[(best_route[i], best_route[i + 1])]})")
