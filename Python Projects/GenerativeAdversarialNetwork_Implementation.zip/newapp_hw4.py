from sklearn.preprocessing import LabelEncoder
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LeakyReLU, BatchNormalization
from sklearn.model_selection import train_test_split
import pandas as pd
from tensorflow.keras.utils import plot_model  # Import the plot_model function

# Function to build the generator model
def build_generator(latent_dim, output_dim):
    model = Sequential()
    model.add(Dense(128, input_dim=latent_dim))
    model.add(LeakyReLU(alpha=0.2))
    model.add(Dense(output_dim, activation='relu'))
    return model

# Function to build the discriminator model
def build_discriminator(input_dim):
    model = Sequential()
    model.add(Dense(128, input_dim=input_dim))
    model.add(LeakyReLU(alpha=0.2))
    model.add(Dense(output_dim, activation='relu'))
    return model

# Function to build the GAN model
def build_gan(generator, discriminator):
    discriminator.trainable = False
    model = Sequential()
    model.add(generator)
    model.add(discriminator)
    return model

# Function to compile the discriminator model
def compile_discriminator(discriminator, learning_rate=0.0002):
    discriminator.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

# Function to compile the GAN model
def compile_gan(gan, learning_rate=0.0002):
    gan.compile(loss='binary_crossentropy', optimizer='adam')

# Define GAN parameters
latent_dim = 10
output_dim = 13  # Number of features in the generated data
epochs = 100
batch_size = 64

# List of input data files
input_files = ['districts_original.csv', 'districts_small.csv', 'districts_medium.csv']

for file_path in input_files:
    # Load data from a CSV file
    data = pd.read_csv(file_path)
    data = data.fillna(0)
    
    # Identify string columns
    string_cols = [0, 2]

    # Use LabelEncoder for string columns
    label_encoders = {}
    for col in string_cols:
        le = LabelEncoder()
        data.iloc[:, col] = le.fit_transform(data.iloc[:, col])
        label_encoders[col] = le

    # Convert the entire data to float
    data = data.astype(float)

    # Build and compile the discriminator
    discriminator = build_discriminator(output_dim)
    compile_discriminator(discriminator)

    # Build the generator
    generator = build_generator(latent_dim, output_dim)

    # Build and compile the GAN
    gan = build_gan(generator, discriminator)
    compile_gan(gan)

    # Training loop
    for epoch in range(epochs):
        # Generate random noise as input to the generator
        noise = np.random.normal(0, 1, (batch_size, latent_dim))

        # Generate synthetic data with the generator
        generated_data = generator.predict(noise)

        # Get a random batch of real data
        idx = np.random.randint(0, data.shape[0], batch_size)
        real_batch = data.iloc[idx]

        # Labels for real and fake data
        labels_real = np.ones((batch_size, 1))
        labels_fake = np.zeros((batch_size, 1))

        # Train the discriminator on real and fake data separately
        d_loss_real = discriminator.train_on_batch(real_batch, labels_real)
        d_loss_fake = discriminator.train_on_batch(generated_data, labels_fake)
        d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

        # Generate new random noise for the generator
        noise = np.random.normal(0, 1, (batch_size, latent_dim))

        # Labels for the generator (tricking the discriminator)
        labels_gan = np.ones((batch_size, 1))

        # Train the generator (via the GAN model)
        g_loss = gan.train_on_batch(noise, labels_gan)

        # Print progress and loss
        if epoch % 100 == 0:
             print(f"Epoch {epoch}, D Loss: {d_loss[0]}, G Loss: {g_loss}, File: {file_path}")

    # Generate synthetic data for evaluation
    synthetic_data = generator.predict(np.random.normal(0, 1, (1000, latent_dim)))
    
    
    means = data.mean()
    stds = data.std()

    # Inverse transform the synthetic data for each column
    synthetic_data_unscaled = (synthetic_data * stds.values) + means.values

    # Convert NumPy array to DataFrame
    synthetic_data_df_unscaled = pd.DataFrame(synthetic_data_unscaled)

    # Save DataFrame to CSV
    output_file = f'synthetic_data_{file_path.replace(".csv", "")}.csv'
    synthetic_data_df_unscaled.to_csv(output_file, index=False)

# Build and compile the GAN
gan = build_gan(generator, discriminator)
compile_gan(gan)

# Visualize the GAN architecture and save the plot to a file
plot_model(gan, to_file='gan_model_plot.png', show_shapes=True, show_layer_names=True)

