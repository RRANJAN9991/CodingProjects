import numpy as np
import random

# Updated Representation of Data
cities_distances = {
    'Boston': {'London': 3, 'Mumbai': 7.6, 'Shanghai': 7.8},
    'London': {'Boston': 3, 'Mumbai': 4.5, 'Shanghai': 5.7},
    'Mumbai': {'Boston': 7.6, 'London': 4.5, 'Shanghai': 3.1},
    'Shanghai': {'Boston': 7.8, 'London': 5.7, 'Mumbai': 3.1}
}

# Function to calculate total distance using the T-Order representation
def calculate_total_distance(route, cities_distances):
    total_distance = 0
    for i in range(len(route) - 1):
        total_distance += cities_distances[route[i]][route[i + 1]]
    total_distance += cities_distances[route[-1]][route[0]]  # Return to the starting city
    return total_distance

# Function to create an initial random route
def create_initial_route(cities_distances):
    cities = list(cities_distances.keys())
    routes = [(city1, city2, cities_distances[city1][city2]) for city1 in cities for city2 in cities if city1 != city2]
    random.shuffle(routes)
    return routes

# Function to initialize a population of routes
def initialize_population(pop_size, num_cities, cities):
    population = []
    for _ in range(pop_size):
        route = create_initial_route(cities)
        population.append(route)
    return population

# Rest of the code remains the same...


# Rest of the code remains the same...

# Function for tournament selection
def tournament_selection(population, distances, tournament_size):
    participants = np.random.choice(len(population), tournament_size, replace=False)
    distances_participants = [calculate_distance(population[i], distances) for i in participants]
    winner_index = participants[np.argmin(distances_participants)]
    return population[winner_index]

# Function for order crossover (OX)
def order_crossover(parent1, parent2):
    size = len(parent1)
    start, end = sorted(np.random.choice(size, 2, replace=False))
    child = [-1] * size
    child[start:end] = parent1[start:end]
    remaining = [item for item in parent2 if item not in child]
    remaining_index = 0
    for i in range(size):
        if child[i] == -1:
            child[i] = remaining[remaining_index]
            remaining_index += 1
    return child

# Function for mutation (swap two cities)
def mutate(route):
    indices = np.random.choice(len(route), 2, replace=False)
    route[indices[0]], route[indices[1]] = route[indices[1]], route[indices[0]]
    return route

def crossover(parent1, parent2, crossover_point):
    # Take the segment from parent1 up to the crossover point
    child_route = parent1[:crossover_point]
    
    # Add the remaining cities from parent2 to the child route
    child_route += [city for city in parent2 if city not in child_route]

    return child_route

# Genetic Algorithm
def genetic_algorithm(distances, pop_size=100, generations=1000, crossover_prob=0.8, mutation_prob=0.2, tournament_size=5):
    num_cities = len(distances)
    population = initialize_population(pop_size, num_cities)

    for generation in range(generations):
        # Selection
        selected_population = [tournament_selection(population, distances, tournament_size) for _ in range(pop_size)]

        # Crossover
        children = []
        for i in range(0, pop_size, 2):
            if np.random.rand() < crossover_prob:
                child1 = order_crossover(selected_population[i], selected_population[i + 1])
                child2 = order_crossover(selected_population[i + 1], selected_population[i])
                children.extend([child1, child2])
            else:
                children.extend([selected_population[i], selected_population[i + 1]])

        # Mutation
        for i in range(pop_size):
            if np.random.rand() < mutation_prob:
                children[i] = mutate(children[i])

        # Elitism: Replace the worst individuals in the population with the best children
        sorted_indices = np.argsort([calculate_distance(route, distances) for route in population])
        for i in range(pop_size):
            if np.random.rand() < 0.2:  # 20% elitism
                population[sorted_indices[i]] = children[i]

        # Print the best route in each generation
        best_route_index = np.argmin([calculate_distance(route, distances) for route in population])
        best_route = population[best_route_index]
        best_distance = calculate_distance(best_route, distances)
        print(f"Generation {generation + 1}, Best Distance: {best_distance}")

    return best_route, best_distance
# Example usage
cities = list(cities_distances.keys())
initial_route = create_initial_route(cities_distances)
print("Initial Route:")
for connection in initial_route:
    print(f"{connection[0]} to {connection[1]} {connection[2]} miles")
