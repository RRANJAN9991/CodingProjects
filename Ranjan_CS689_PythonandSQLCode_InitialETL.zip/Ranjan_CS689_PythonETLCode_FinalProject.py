import pandas as pd
from datetime import datetime

file_path = 'Full_Data_CS689.csv'


df = pd.read_csv(file_path)
# Rename columns to lowercase and remove spaces
df.columns = df.columns.str.lower().str.replace(' ', '')
print(df.columns)

# Extract columns of interest for contributingfactorvehicle_dim
factors = df[["contributingfactorvehicle1", 
              "contributingfactorvehicle2", 
              "contributingfactorvehicle3", 
              "contributingfactorvehicle4", 
              "contributingfactorvehicle5"]]

# Drop duplicate rows to keep unique combinations
contributingfactordim = factors.drop_duplicates()

# Reset index
contributingfactordim.reset_index(drop=True, inplace=True)

# Add an ID column to the dimension table
contributingfactordim['factor_id'] = contributingfactordim.index + 1


# Initialize additional columns for SCD Type 3
update_date = datetime.now().strftime('%Y-%m-%d')
previous_factor = contributingfactordim['contributingfactorvehicle1']

# Insert new columns at specific positions
contributingfactordim.insert(len(contributingfactordim.columns) - 1, 'previous_factor_1', previous_factor)
contributingfactordim.insert(len(contributingfactordim.columns) - 1, 'update_date', update_date)


# Extract columns of interest for vehicletypecode_dim
vehicle_types = df[["vehicletypecode1", 
                    "vehicletypecode2", 
                    "vehicletypecode3", 
                    "vehicletypecode4", 
                    "vehicletypecode5"]]

# Drop duplicate rows to keep unique combinations
vehicle_dim = vehicle_types.drop_duplicates()

# Reset index
vehicle_dim.reset_index(drop=True, inplace=True)

# Add an ID column to the dimension table
vehicle_dim['vehicle_type_id'] = vehicle_dim.index + 1

# Add necessary columns for SCD Type 2
if 'version' not in vehicle_dim.columns:
    vehicle_dim.insert(len(vehicle_dim.columns) - 1, 'version', 1)

if 'effective_start_date' not in vehicle_dim.columns:
    vehicle_dim.insert(len(vehicle_dim.columns) - 2, 'effective_start_date', datetime.now())

if 'effective_end_date' not in vehicle_dim.columns:
    vehicle_dim.insert(len(vehicle_dim.columns) - 3, 'effective_end_date', pd.Timestamp('2262-04-11 23:47:16'))








# Extract columns of interest for consequence_dim
entity_types = df[['numberofpersonsinjured', 'numberofpersonskilled',
                   'numberofpedestriansinjured', 'numberofpedestrianskilled',
                   'numberofcyclistinjured', 'numberofcyclistkilled',
                   'numberofmotoristinjured', 'numberofmotoristkilled']]

# Drop duplicate rows to keep unique combinations
entity_dim = entity_types.drop_duplicates()

# Reset index
entity_dim.reset_index(drop=True, inplace=True)


# Add an ID column to the dimension table
entity_dim['injurkilled_id'] = entity_dim.index + 1

print(entity_dim.dtypes)

# Select relevant columns for weather conditions
weather_columns = ['conds', 'icon', 'fog', 'rain', 'snow', 'hail', 'thunder', 'tornado']

# Extract relevant columns
weather_conditions = df[weather_columns]

# Drop duplicate rows to keep unique values
weathercond_dim = weather_conditions.drop_duplicates()

# Reset index
weathercond_dim.reset_index(drop=True, inplace=True)

# Create all possible combinations for each level of hierarchy
icon_values = weathercond_dim['icon'].unique()
conds_values = weathercond_dim['conds'].unique()
binary_values = [0, 1]  # Possible values for binary weather conditions

# Create a DataFrame to store all possible combinations
dimension_table = pd.DataFrame(columns=weather_columns)

# Iterate over all possible combinations and append to the dimension table
for icon in icon_values:
    for conds in conds_values:
        for fog in binary_values:
            for rain in binary_values:
                for snow in binary_values:
                    for hail in binary_values:
                        for thunder in binary_values:
                            for tornado in binary_values:
                                dimension_table = dimension_table.append({
                                    'conds': conds,
                                    'icon': icon,
                                    'fog': fog,
                                    'rain': rain,
                                    'snow': snow,
                                    'hail': hail,
                                    'thunder': thunder,
                                    'tornado': tornado
                                }, ignore_index=True)


# Add an ID column to the dimension table
dimension_table['weather_condition_id'] = range(1, len(dimension_table) + 1)





# Select relevant columns for weather conditions
weather_columns = ['tempi', 'wspdm', 'visi']

# Extract relevant columns
weather_data = df[weather_columns]

# Drop duplicate rows to keep unique combinations
weather_dim = weather_data.drop_duplicates()

# Reset index
weather_dim.reset_index(drop=True, inplace=True)

# Add an ID column to the dimension table
weather_dim['weather_id'] = range(1, len(weather_dim) + 1)



# Convert 'Full Crash Date' column to datetime format
df['fullcrashdate'] = pd.to_datetime(df['fullcrashdate'])

# Create a time dimension table with day grain
crashdateday_dimension = pd.DataFrame()
crashdateday_dimension['Date'] = df['fullcrashdate']
crashdateday_dimension['Day'] = df['fullcrashdate'].dt.day
crashdateday_dimension['Month'] = df['fullcrashdate'].dt.month
crashdateday_dimension['Year'] = df['fullcrashdate'].dt.year
crashdateday_dimension['Weekday'] = df['fullcrashdate'].dt.day_name()

# Create a column indicating weekday or weekend
crashdateday_dimension['Weekend'] = crashdateday_dimension['Weekday'].apply(lambda x: 'Weekend' if x in ['Saturday', 'Sunday'] else 'Weekday')

# Create a time dimension table with second grain
crashdatesecond_dimension = pd.DataFrame()
crashdatesecond_dimension['fullcrashdate'] = df['fullcrashdate']
crashdatesecond_dimension['Hour'] = df['fullcrashdate'].dt.hour
crashdatesecond_dimension['Minute'] = df['fullcrashdate'].dt.minute
crashdatesecond_dimension['Second'] = df['fullcrashdate'].dt.second




## FACT TABLE 1 (Weatheraccidentfact_v1)

# Combine the relevant columns representing weather conditions
weather_conditions_columns = ['conds', 'icon', 'fog', 'rain', 'snow', 'hail', 'thunder', 'tornado']
df_weather_conditions = df[weather_conditions_columns]

# Merge the original dataset with the dimension table based on weather condition columns
merged_df = pd.merge(df[['collision_id']], df_weather_conditions, 
                     left_index=True, right_index=True, how='inner')
merged_df = pd.merge(merged_df, dimension_table, 
                     on=weather_conditions_columns, how='left')


# Check if all weather condition columns have a value of 0
merged_df['condition_exists'] = (merged_df[weather_conditions_columns].sum(axis=1) > 0).astype(int)


# Extract the 'COLLISION_ID', 'weather_condition_id', and 'condition_exists' columns
fact_table = merged_df[['collision_id', 'weather_condition_id', 'condition_exists']]




# Combine the relevant columns representing vehicle types
vehicle_columns = ['vehicletypecode1', 'vehicletypecode2', 
                   'vehicletypecode3', 'vehicletypecode4', 
                   'vehicletypecode5']
df_vehicle_types = df[vehicle_columns]

# Merge the original dataset with the vehicle type dimension table based on vehicle type columns
merged_df_vehicle = pd.merge(df[['collision_id']], df_vehicle_types, 
                              left_index=True, right_index=True, how='inner')
merged_df_vehicle = pd.merge(merged_df_vehicle, vehicle_dim, 
                             on=vehicle_columns, how='left')

# Extract the 'COLLISION_ID', 'VEHICLE TYPE CODE 1', and 'vehicle_type_id' columns
fact_table_vehicle = merged_df_vehicle[['collision_id', 'vehicletypecode1', 'vehicle_type_id']]

# Merge the fact_table_vehicle with the existing fact_table to include vehicle_type_id
fact_table = pd.merge(fact_table, fact_table_vehicle, on='collision_id', how='inner')

# Combine the relevant columns representing entity dimensions
entity_columns = ['numberofpersonsinjured', 'numberofpersonskilled',
                  'numberofpedestriansinjured', 'numberofpedestrianskilled',
                  'numberofcyclistinjured', 'numberofcyclistkilled',
                  'numberofmotoristinjured', 'numberofmotoristkilled']
df_entity_types = df[entity_columns]

# Merge the original dataset with the entity dimension table based on entity columns
merged_df_entity = pd.merge(df[['collision_id']], df_entity_types, 
                             left_index=True, right_index=True, how='inner')
merged_df_entity = pd.merge(merged_df_entity, entity_dim, 
                            on=entity_columns, how='left')

# Extract the 'COLLISION_ID', 'NUMBER OF PERSONS KILLED', and 'injurkilled_id' columns
fact_table_entity = merged_df_entity[['collision_id', 'numberofpersonskilled', 'injurkilled_id']]


# Merge the fact_table_entity with the existing fact_table to include injurkilled_id
fact_table = pd.merge(fact_table, fact_table_entity, on='collision_id', how='inner')



# Combine the relevant columns representing contributing factors
contributing_factor_columns = ["contributingfactorvehicle1", 
              "contributingfactorvehicle2", 
              "contributingfactorvehicle3", 
              "contributingfactorvehicle4", 
              "contributingfactorvehicle5"]
df_contributing_factors = df[contributing_factor_columns]

# Merge the original dataset with the contributing factor dimension table based on contributing factor columns
merged_df_contributing_factors = pd.merge(df[['collision_id']], df_contributing_factors, 
                                          left_index=True, right_index=True, how='inner')
merged_df_contributing_factors = pd.merge(merged_df_contributing_factors, contributingfactordim, 
                                          on=contributing_factor_columns, how='left')

# Extract the 'COLLISION_ID', 'CONTRIBUTING FACTOR VEHICLE 1', and 'factor_id' columns
fact_table_contributing_factors = merged_df_contributing_factors[['collision_id', "contributingfactorvehicle1", 'factor_id']]

# Merge the fact_table_contributing_factors with the existing fact_table
fact_table = pd.merge(fact_table, fact_table_contributing_factors, on='collision_id', how='inner')
## Merge 'Full Crash Date' from the original DataFrame into Fact Table 
fact_table = pd.merge(fact_table, df[['collision_id', 'fullcrashdate']], 
                                on='collision_id', how='left')

fact_table = pd.merge(fact_table, df[['collision_id', 'fullcrashdate']], 
                                on='collision_id', how='left')
fact_table.drop(columns=['fullcrashdate_y'], inplace=True)
# Tranformations
df['sum_of_pedmot_inj'] = df['numberofpedestriansinjured'] + df['numberofmotoristinjured']


fact_table = pd.merge(fact_table, df[['collision_id', 'sum_of_pedmot_inj']], on='collision_id', how='left')
df['proportion_ped_injured'] = df['numberofpedestriansinjured'] / df['numberofpersonsinjured']


fact_table = pd.merge(fact_table, df[['collision_id', 'proportion_ped_injured']], on='collision_id', how='left')



# FACT TABLE 2 (Weatheraccidentfact_v2)


# Merge with weather dimension table to obtain Weather ID
merged_df_weather = pd.merge(df[['collision_id', 'tempi', 'wspdm', 'visi']], weather_dim, 
                             on=['tempi', 'wspdm', 'visi'], how='left')
# Transformation
# Calculate temperature range
def calculate_temperature_range(temperature):
    if temperature <= 25:
        return 'Range 1: -50 to 25'
    elif 26 <= temperature <= 50:
        return 'Range 2: 26 to 50'
    elif 51 <= temperature <= 75:
        return 'Range 3: 51 to 75'
    elif 76 <= temperature <= 100:
        return 'Range 4: 76 to 100'
    elif 101 <= temperature <= 125:
        return 'Range 5: 101 to 125'
    else:
        return 'Other'

merged_df_weather['temperature_range'] = merged_df_weather['tempi'].apply(calculate_temperature_range)


fact_table_2 = merged_df_weather[['collision_id', 'weather_id', 'temperature_range']]

# Merge Fact Table #2 with the original dataset to retrieve 'NUMBER OF PERSONS KILLED' data
fact_table_2_merged = pd.merge(fact_table_2, df[['collision_id', 'numberofpersonskilled']], 
                               on='collision_id', how='left')

# Group by 'Temperature Range' and cumulate the 'NUMBER OF PERSONS KILLED' values
fact_table_2_merged['cumulative_num_persons_killed'] = fact_table_2_merged.groupby('temperature_range')['numberofpersonskilled'].cumsum()



entity_columns = ['numberofpersonsinjured', 'numberofpersonskilled',
                  'numberofpedestriansinjured', 'numberofpedestrianskilled',
                  'numberofcyclistinjured', 'numberofcyclistkilled',
                  'numberofmotoristinjured', 'numberofmotoristkilled']
df_entity_types = df[entity_columns]

# Merge the original dataset with the entity dimension table based on entity columns
merged_df_entity = pd.merge(df[['collision_id']], df_entity_types, 
                             left_index=True, right_index=True, how='inner')
merged_df_entity = pd.merge(merged_df_entity, entity_dim, 
                            on=entity_columns, how='left')

# Extract the 'COLLISION_ID', 'NUMBER OF PERSONS KILLED', and 'injurkilled_id' columns
fact_table_entity = merged_df_entity[['collision_id', 'numberofpersonskilled', 'injurkilled_id']]

# Merge the fact_table_entity with the existing fact_table to include injurkilled_id
fact_table_2_merged = pd.merge(fact_table_2_merged, fact_table_entity, on='collision_id', how='inner')





# Merge 'Full Crash Date' from the original DataFrame into Fact Table #2
fact_table_2_merged = pd.merge(fact_table_2_merged, df[['collision_id', 'fullcrashdate']], 
                                on='collision_id', how='left')
# Extract the month from 'Full Crash Date'
fact_table_2_merged['Month'] = fact_table_2_merged['fullcrashdate'].dt.month
# Transformation
# Map month to season
def get_season(month):
    if month in [12, 1, 2]:
        return 'Winter'
    elif month in [3, 4, 5]:
        return 'Spring'
    elif month in [6, 7, 8]:
        return 'Summer'
    else:
        return 'Fall'

# Apply the function to create the season  column
fact_table_2_merged['Season'] = fact_table_2_merged['Month'].apply(get_season)
# Remove the 'Month' column from the fact_table_2_merged
fact_table_2_merged.drop(columns=['Month'], inplace=True)


# Constructing Fact Table #2 with cumulative number of pedestrians injured by season
fact_table_2_with_injuries = pd.merge(fact_table_2_merged, df[['collision_id', 'numberofpedestriansinjured']], 
                                      on='collision_id', how='left')

# Group by 'Season' and cumulate the 'NUMBER OF PEDESTRIANS INJURED' values
fact_table_2_with_injuries['cumulative_num_pedestrians_injured'] = fact_table_2_with_injuries.groupby('Season')['numberofpedestriansinjured'].cumsum()
# Merge the fact_table_entity with the existing fact_table to include injurkilled_id
fact_table_2_merged = pd.merge(fact_table_2_merged, fact_table_2_with_injuries, on='collision_id', how='inner')
# Transformation
# Define a function to categorize visibility
def categorize_visibility(visi):
    if visi <= 2.5:
        return '0 to 2.5'
    elif 2.6 <= visi <= 5:
        return '2.6 to 5'
    elif 5.1 <= visi <= 7.5:
        return '5.1 to 7.5'
    elif 7.6 <= visi <= 11:
        return '7.6 to 11'
    else:
        return 'NA'

# Apply the function to create the 'visibility' column
fact_table_2_merged['Visibility'] = df['visi'].apply(categorize_visibility)
fact_table_2_merged.drop(columns=['weather_id_y'], inplace=True)
fact_table_2_merged.drop(columns=['temperature_range_y'], inplace=True)
fact_table_2_merged.drop(columns=['numberofpersonskilled_x_y'], inplace=True)
fact_table_2_merged.drop(columns=['numberofpersonskilled_y_x'], inplace=True)
fact_table_2_merged.drop(columns=['cumulative_num_persons_killed_y'], inplace=True)
fact_table_2_merged.drop(columns=['numberofpersonskilled_y_y'], inplace=True)
fact_table_2_merged.drop(columns=['injurkilled_id_y'], inplace=True)
fact_table_2_merged.drop(columns=['Season_y'], inplace=True)
fact_table_2_merged.drop(columns=['fullcrashdate_y'], inplace=True)


import psycopg2
from psycopg2 import sql


# Convert DataFrames to a list of tuples
data_dim_contrib = [tuple(row) for row in contributingfactordim.to_numpy()]
data_dim_vehicle = [tuple(row) for row in vehicle_dim.to_numpy()]
data_dim_entity = [tuple(row) for row in entity_dim.itertuples(index=False)]
data_dim_weathercond = [tuple(row) for row in dimension_table.to_numpy()]
data_dim_weather = [tuple(row) for row in weather_dim.to_numpy()]
data_dim_daygrain = [tuple(row) for row in crashdateday_dimension.to_numpy()]
data_dim_secondgrain = [tuple(row) for row in crashdatesecond_dimension.to_numpy()]


# Define the INSERT statements
insert_statement_contrib = sql.SQL('INSERT INTO ContributingFactorVehicle_Dim (contributingfactorvehicle1, contributingfactorvehicle2, contributingfactorvehicle3, contributingfactorvehicle4, contributingfactorvehicle5, previous_factor_1, update_date, factor_id) VALUES {}').format(sql.SQL(',').join(map(sql.Literal, data_dim_contrib)))
insert_statement_vehicle = sql.SQL('INSERT INTO VehicleTypeCode_Dim (vehicletypecode1, vehicletypecode2, vehicletypecode3, vehicletypecode4, vehicletypecode5, effective_end_date, effective_start_date, version, vehicle_type_id) VALUES {}').format(sql.SQL(',').join(map(sql.Literal, data_dim_vehicle)))
insert_statement_entity = sql.SQL('INSERT INTO Consequence_Dim (numberofpersonsinjured, numberofpersonskilled, numberofpedestriansinjured, numberofpedestrianskilled, numberofcyclistinjured, numberofcyclistkilled, numberofmotoristinjured, numberofmotoristkilled, injurkilled_id) VALUES {}').format(sql.SQL(',').join(map(sql.Literal, data_dim_entity)))
insert_statement_weathercond = sql.SQL('INSERT INTO WeatherConditions_Dim (conds, icon, fog, rain, snow, hail, thunder, tornado, weather_condition_id) VALUES {}').format(sql.SQL(',').join(map(sql.Literal, data_dim_weathercond)))
insert_statement_weather = sql.SQL('INSERT INTO Weather_Dim (tempi, wspdm, visi, weather_id) VALUES {}').format(sql.SQL(',').join(map(sql.Literal, data_dim_weather)))
insert_statement_daygrain = sql.SQL('INSERT INTO CrashDateDayGrain_Dim (date, day, month, year, weekday, weekend) VALUES {}').format(sql.SQL(',').join(map(sql.Literal, data_dim_daygrain)))
insert_statement_secondgrain = sql.SQL('INSERT INTO CrashDateSecondGrain_Dim (fullcrashdate, hour, minute, second) VALUES {}').format(sql.SQL(',').join(map(sql.Literal, data_dim_secondgrain)))
# Convert DataFrame to a list of tuples
data_fact_V1 = [tuple(row) for row in fact_table.to_numpy()]
data_fact_V2 = [tuple(row) for row in fact_table_2_merged.to_numpy()]
# Define the INSERT statements
insert_statement_factV1 = sql.SQL('INSERT INTO WeatherAccidentFact_V1 (collision_id, weather_condition_id, condition_exists, vehicle_type_id, numberofpersonskilled, injurkilled_id, factor_id, fullcrashdate_x, sum_of_pedmot_inj, proportion_ped_injured) VALUES {}').format(sql.SQL(',')
                                                                                                                                                                                                             .join(map(sql.Literal, data_fact_V1)))
insert_statement_factV2 = sql.SQL('INSERT INTO WeatherAccidentFact_V2 (collision_id, weather_id_x, temperature_range_x, numberofpersonskilled_x_x, cumulative_num_persons_killed_x, injurkilled_id_x, fullcrashdate_x, Season_x, numberofpedestriansinjured, cumulative_num_pedestrians_injured, Visibility) VALUES {}').format(sql.SQL(',').join(map(sql.Literal, data_fact_V2)))
# Connect to the database
hostname = 'localhost'
database = 'AccidentWeather'
username = 'postgres'
pwd = 'Password Removed for Security Reasons'
port_id = 5432
conn = None
cur = None
try:
    conn = psycopg2.connect(host = hostname, dbname = database, user = username, password = pwd, port = port_id)
    cur = conn.cursor()
    # Execute the insert statements
    cur.execute(insert_statement_contrib)
   
    cur.execute(insert_statement_vehicle)

    cur.execute(insert_statement_entity)
  
    cur.execute(insert_statement_weathercond)

    cur.execute(insert_statement_weather)
  
    cur.execute(insert_statement_daygrain)

    cur.execute(insert_statement_secondgrain)
  
    cur.execute(insert_statement_factV1)
    cur.execute(insert_statement_factV2)

    # Commit the transaction
    conn.commit()
    print("Data loaded into fact table successfully!")
except Exception as error:
    print(error)
finally:
    if cur is not None:
        cur.close()
    if conn is not None:
        conn.close()



