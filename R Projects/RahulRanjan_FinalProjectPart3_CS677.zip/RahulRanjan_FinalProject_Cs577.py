"""
Rahul Ranjan
Class: CS 677
Date: 8/16/2023
Project Part 1
Description of Problem (just a 1-2 line summary!): This part of the project uses Logistic Regression classifier model to predict class labels for player positions.
"""
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.impute import SimpleImputer


#Read the CSV data into a DataFrame
df = pd.read_csv("CS677_FinalProject_UpdatedDataV2.csv")

#Define the selected features
selected_features = ['Age', 'FG', 'FGA', 'FG%', '3P', '3PA', '3P%', '2P', '2PA', '2P%', 'FT', 'FTA', 'FT%',
                     'ORB', 'DRB', 'TRB', 'AST', 'STL', 'BLK', 'TOV', 'PF', 'PTS']

#Create the feature matrix X and the target vector y
X = df[selected_features]
y = df['Pos']

#Initialize the LabelEncoder
label_encoder = LabelEncoder()

#Convert the player positions to numerical labels
y_encoded = label_encoder.fit_transform(y)

#Split the data into training and testing sets (80% training, 20% testing)
X_train, X_test, y_train_encoded, y_test_encoded = train_test_split(X, y_encoded, test_size=0.2, random_state=42)

#Initialize the SimpleImputer to handle missing values
imputer = SimpleImputer(strategy='mean')  # You can choose other strategies like 'median', 'most_frequent', etc.

#Fit and transform the imputer on the training data
X_train_imputed = imputer.fit_transform(X_train)

#Transform the test data using the trained imputer
X_test_imputed = imputer.transform(X_test)

#Initialize the Logistic Regression classifier
clf = LogisticRegression()

#Train the classifier on the training data
clf.fit(X_train_imputed, y_train_encoded)

#Predict player positions on the testing data
y_pred_encoded = clf.predict(X_test_imputed)

#Evaluate the classifier's performance
accuracy = accuracy_score(y_test_encoded, y_pred_encoded)
classification_report = classification_report(y_test_encoded, y_pred_encoded, target_names=label_encoder.classes_)
confusion_mat = confusion_matrix(y_test_encoded, y_pred_encoded)

#Convert the confusion matrix to a labeled DataFrame
confusion_df = pd.DataFrame(confusion_mat, index=label_encoder.classes_, columns=label_encoder.classes_)

#Print the evaluation metrics
print("Accuracy:", accuracy)
print("Classification Report:\n", classification_report)
print("Confusion Matrix:\n", confusion_df)




