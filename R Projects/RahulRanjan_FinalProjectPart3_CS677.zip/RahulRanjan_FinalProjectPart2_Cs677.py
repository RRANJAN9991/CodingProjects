"""
Rahul Ranjan
Class: CS 677
Date: 8/16/2023
Project Part 2
Description of Problem (just a 1-2 line summary!): This part of the project uses Random Forest classifier model to predict class labels for player positions.
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
from sklearn.impute import SimpleImputer

#Read the CSV data into a DataFrame
df = pd.read_csv("CS677_FinalProject_UpdatedDataV2.csv")

#Define the selected features
selected_features = ['Age', 'FG', 'FGA', 'FG%', '3P', '3PA', '3P%', '2P', '2PA', '2P%', 'FT', 'FTA', 'FT%',
                     'ORB', 'DRB', 'TRB', 'AST', 'STL', 'BLK', 'TOV', 'PF', 'PTS']

#Create the feature matrix X and the target vector y
X = df[selected_features]
y = df['Pos']  

#Initialize the LabelEncoder
label_encoder = LabelEncoder()

#Convert the player positions to numerical labels
y_encoded = label_encoder.fit_transform(y)

#Lists to store accuracy and best combination of N and d
accuracies = []
best_N, best_d = None, None
best_accuracy = 0

N_values = range(1, 11)  #Change the range of N as needed
d_values = range(1, 6)  #Change the range of d as needed

#Loop over different values of N and d
for N in N_values:
    for d in d_values:
        #Split the data into training and testing sets (80% training, 20% testing)
        X_train, X_test, y_train_encoded, y_test_encoded = train_test_split(X, y_encoded, test_size=0.2, random_state=42)

        #Initialize the SimpleImputer to handle missing values
        imputer = SimpleImputer(strategy='mean')  

        #Fit and transform the imputer on the training data
        X_train_imputed = imputer.fit_transform(X_train)

        #Transform the test data using the trained imputer
        X_test_imputed = imputer.transform(X_test)

        #Initialize the Random Forest classifier
        clf = RandomForestClassifier(n_estimators=N, max_depth=d, random_state=42)

        #Train the classifier on the training data
        clf.fit(X_train_imputed, y_train_encoded)

        #Predict player positions on the testing data
        y_pred_encoded = clf.predict(X_test_imputed)

        #Calculate accuracy and store it
        accuracy = accuracy_score(y_test_encoded, y_pred_encoded)
        accuracies.append(accuracy)

        #Update the best combination if needed
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            best_N, best_d = N, d

#Print the accuracies and best combination of N and d
print("Best Combination of N and d:")
print(f"N = {best_N}, d = {best_d}")

#Step 3: Train the Random Forest Classifier with the Best Combination of N and d
X_train, X_test, y_train_encoded, y_test_encoded = train_test_split(X, y_encoded, test_size=0.2, random_state=42)

#Initialize the SimpleImputer to handle missing values for the best model
imputer_best = SimpleImputer(strategy='mean')
X_train_imputed_best = imputer_best.fit_transform(X_train)
X_test_imputed_best = imputer_best.transform(X_test)

clf_best = RandomForestClassifier(n_estimators=best_N, max_depth=best_d, random_state=42)
clf_best.fit(X_train_imputed_best, y_train_encoded)

#Step 4: Predict Class Labels for X_test using the Best Model
y_pred_encoded_best = clf_best.predict(X_test_imputed_best)

#Step 5: Compute Accuracy, Confusion Matrix, and Classification Report for the Best Model
accuracy_best = accuracy_score(y_test_encoded, y_pred_encoded_best)
confusion_mat_best = confusion_matrix(y_test_encoded, y_pred_encoded_best)
classification_report_best = classification_report(y_test_encoded, y_pred_encoded_best, target_names=label_encoder.classes_)

#Print the evaluation metrics for the best model
print("Accuracy for Best Combination:", accuracy_best)
print("Confusion Matrix for Best Combination:\n", confusion_mat_best)
print("Classification Report for Best Combination:\n", classification_report_best)

#Extract TN, FP, FN, TP from the confusion matrix
TN = confusion_mat_best[0, 0]
FP = confusion_mat_best[0, 1]
FN = confusion_mat_best[1, 0]
TP = confusion_mat_best[1, 1]

#Calculate the precision, recall, F1-score, TPR, and TNR
precision = TP / (TP + FP)
recall = TP / (TP + FN)
f1_score = 2 * (precision * recall) / (precision + recall)
TPR = recall
TNR = TN / (TN + FP)

#Display the results
print("Precision:", precision)
print("Recall (TPR):", recall)
print("F1-score:", f1_score)
print("True Positive Rate (TPR):", TPR)
print("True Negative Rate (TNR):", TNR)

#Step 6: Get Feature Importances for the Best Model
importances_best = clf_best.feature_importances_

#Create a DataFrame to store feature importances with corresponding feature names
feature_importance_df_best = pd.DataFrame({'Feature': selected_features, 'Importance': importances_best})

#Sort the DataFrame by feature importance in descending order
feature_importance_df_best = feature_importance_df_best.sort_values(by='Importance', ascending=False)

#Plot the feature importances for the best model
plt.figure(figsize=(10, 6))
sns.barplot(x='Importance', y='Feature', data=feature_importance_df_best)
plt.title("Feature Importance for Best Combination of N and d")
plt.xlabel("Importance")
plt.ylabel("Feature")
plt.show()
